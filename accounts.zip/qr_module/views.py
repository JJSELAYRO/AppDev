import uuid
import json
import math
import qrcode
import qrcode.image.svg
from io import BytesIO
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from accounts.models import UserProfile, Student, Teacher, ClassGroup
from attendance.models import QRSession, Attendance, SMSLog
from twilio.rest import Client


def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate distance in meters between two GPS coordinates using Haversine formula"""
    R = 6371000  # Earth's radius in meters
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = math.sin(delta_lat / 2) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    distance = R * c
    return round(distance)


def send_sms_notification(parent, student_name, attendance_time):
    """Send SMS notification to parent using Twilio"""
    if not all([settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN, settings.TWILIO_PHONE_NUMBER]):
        return False, "Twilio credentials not configured"
    
    try:
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        
        message_body = f"Your child {student_name} is PRESENT at {attendance_time.strftime('%I:%M %p')}. (Sent from Twilio trial account)"
        
        message = client.messages.create(
            body=message_body,
            from_=settings.TWILIO_PHONE_NUMBER,
            to=parent.contact_number
        )
        
        return True, message.sid
    except Exception as e:
        return False, str(e)


@login_required
def generate_qr_session(request, class_id):
    """Generate a new QR code session for a class"""
    try:
        if request.user.profile.role != 'teacher':
            return JsonResponse({'success': False, 'error': 'Access denied. Teacher only.'})
    except:
        return JsonResponse({'success': False, 'error': 'Access denied.'})
    
    try:
        teacher = request.user.profile.teacher_profile
        class_group = get_object_or_404(ClassGroup, id=class_id)
        
        # Deactivate old sessions for this class
        QRSession.objects.filter(class_group=class_group, is_active=True).update(is_active=False)
        
        # Generate unique QR value
        qr_value = str(uuid.uuid4())
        
        # Create new session (expires in 2 hours)
        session = QRSession.objects.create(
            class_group=class_group,
            teacher=teacher,
            qr_value=qr_value,
            is_active=True,
            expires_at=timezone.now() + timezone.timedelta(hours=2)
        )
        
        # Generate QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=2)
        qr.add_data(qr_value)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        
        # Save QR image
        qr_filename = f"qr_{session.id}_{qr_value[:8]}.png"
        from django.core.files.base import ContentFile
        session.qr_image.save(qr_filename, ContentFile(buffer.read()), save=True)
        
        return JsonResponse({
            'success': True,
            'session_id': session.id,
            'qr_value': qr_value,
            'expires_at': session.expires_at.isoformat()
        })
    
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def view_qr_session(request, session_id):
    """View QR code for a session"""
    try:
        if request.user.profile.role != 'teacher':
            messages.error(request, 'Access denied. Teacher only.')
            return redirect('dashboard')
    except:
        messages.error(request, 'Access denied.')
        return redirect('login')
    
    session = get_object_or_404(QRSession, id=session_id)
    
    # Generate QR code image
    qr = qrcode.QRCode(version=1, box_size=10, border=2)
    qr.add_data(session.qr_value)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    qr_base64 = buffer.getvalue().hex()
    
    # Get live attendance for this session
    attendances = Attendance.objects.filter(session=session).select_related(
        'student', 'student__user_profile__user'
    ).order_by('-time_in')
    
    context = {
        'session': session,
        'class_group': session.class_group,
        'qr_base64': qr_base64,
        'attendances': attendances,
    }
    return render(request, 'qr_module/view_qr.html', context)


@login_required
def scan_qr_page(request):
    """Page for students to scan QR codes"""
    try:
        if request.user.profile.role != 'student':
            messages.error(request, 'Access denied. Student only.')
            return redirect('dashboard')
    except:
        messages.error(request, 'Access denied.')
        return redirect('login')
    
    student = request.user.profile.student_profile
    
    context = {
        'student': student,
        'school_lat': settings.SCHOOL_LATITUDE,
        'school_lng': settings.SCHOOL_LONGITUDE,
        'gps_radius': settings.GPS_RADIUS_METERS,
    }
    return render(request, 'qr_module/scan_qr.html', context)


@csrf_exempt
@require_http_methods(["POST"])
def submit_attendance(request):
    """Submit attendance after scanning QR code"""
    try:
        data = json.loads(request.body)
        
        qr_value = data.get('qr_value')
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        
        if not all([qr_value, latitude, longitude]):
            return JsonResponse({
                'success': False,
                'error': 'Missing required data. QR code and GPS location required.'
            })
        
        # Get student
        try:
            student = request.user.profile.student_profile
        except:
            return JsonResponse({
                'success': False,
                'error': 'Student profile not found.'
            })
        
        # Validate QR session
        try:
            session = QRSession.objects.get(
                qr_value=qr_value,
                is_active=True,
                expires_at__gt=timezone.now()
            )
        except QRSession.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Invalid or expired QR code.'
            })
        
        # Validate GPS location
        distance = calculate_distance(
            settings.SCHOOL_LATITUDE,
            settings.SCHOOL_LONGITUDE,
            float(latitude),
            float(longitude)
        )
        
        if distance > settings.GPS_RADIUS_METERS:
            return JsonResponse({
                'success': False,
                'error': f'You are {distance} meters away from school. Must be within {settings.GPS_RADIUS_METERS} meters.'
            })
        
        # Check for duplicate attendance today
        today = timezone.now().date()
        existing_attendance = Attendance.objects.filter(
            student=student,
            session=session,
            date=today
        ).first()
        
        if existing_attendance:
            return JsonResponse({
                'success': False,
                'error': 'You have already recorded attendance for this session today.'
            })
        
        # Determine status (Late if after 8:00 AM)
        current_time = timezone.now().time()
        status = 'present'
        if current_time.hour >= 8 and current_time.minute > 0:
            status = 'late'
        
        # Create attendance record
        attendance = Attendance.objects.create(
            student=student,
            session=session,
            class_group=session.class_group,
            status=status,
            latitude=latitude,
            longitude=longitude,
            distance_from_school=distance,
            sms_sent=False
        )
        
        # Send SMS notification if parent exists
        sms_result = None
        if student.parent:
            success, message = send_sms_notification(
                student.parent,
                student.user_profile.user.get_full_name(),
                attendance.time_in
            )
            
            attendance.sms_sent = success
            attendance.sms_sent_at = timezone.now() if success else None
            attendance.save()
            
            # Log SMS
            SMSLog.objects.create(
                parent=student.parent,
                attendance=attendance,
                message=message if not success else "SMS sent successfully",
                status='sent' if success else 'failed',
                error_message=message if not success else None
            )
            
            sms_result = {'sent': success, 'message': message}
        
        return JsonResponse({
            'success': True,
            'message': f'Attendance recorded successfully! Status: {status.title()}',
            'status': status,
            'distance': distance,
            'sms_sent': sms_result
        })
    
    except json.JSONDecodeError:
        return JsonResponse({
            'success': False,
            'error': 'Invalid JSON data.'
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })
